import os
from pathlib import Path

from npg_chamber.workflows.legacy_runner import LEGACY_WORKFLOWS, workflow_environment


def test_launcher_blocks_next_phase_until_verified_serial_handoff():
    runner = Path("npg_chamber/workflows/legacy_runner.py").read_text(encoding="utf-8")
    gui = Path("npg_chamber/gui_launcher.py").read_text(encoding="utf-8")

    assert 'verify_all_chamber_ports_released(context=f"before phase {key}")' in runner
    assert "verify_all_chamber_ports_released(context=label)" in runner
    assert "SerialHandoffError" in gui
    assert "The next phase was blocked" in gui
    assert "All chamber COM ports were reset and released" in gui


def test_phase_process_environment_imports_the_current_project_tree():
    workflow = LEGACY_WORKFLOWS["dpdbba"]
    existing = os.pathsep.join(["C:\\older-copy", "C:\\shared-tools"])
    env = workflow_environment(workflow, extra_env={"PYTHONPATH": existing})

    entries = env["PYTHONPATH"].split(os.pathsep)
    expected_root = Path("npg_chamber").resolve().parent

    assert Path(entries[0]).resolve() == expected_root
    assert str(expected_root) not in entries[1:]
    assert env["NPG_CHAMBER_WORKFLOW_KEY"] == "dpdbba"


def test_phase_two_and_four_reset_buffers_before_closing_serial_ports():
    phase2 = Path("npg_chamber/legacy_scripts/02_sputtering_annealing_legacy.py").read_text(
        encoding="utf-8"
    )
    phase4 = Path("npg_chamber/legacy_scripts/04_npg_annealings_legacy.py").read_text(
        encoding="utf-8"
    )

    assert "reset_serial_buffers_and_close" in phase2
    assert '"XGS600 pressure port"' in phase2
    assert '"Oven PID port"' in phase2
    assert '"Keysight power-supply port"' in phase2

    assert "reset_serial_buffers_and_close" in phase4
    assert '"Oven PID port"' in phase4
    assert '"Keysight power-supply port"' in phase4
    assert '"Arduino CK-1 temperature port"' in phase4
