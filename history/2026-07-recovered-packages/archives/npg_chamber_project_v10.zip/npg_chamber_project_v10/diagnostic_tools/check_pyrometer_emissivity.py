"""Read or safely change the IMPAC IPE 140 emissivity on COM10.

Run from the project folder with:
    python diagnostic_tools/check_pyrometer_emissivity.py

The tool reads the proven 11-digit `pa` parameter response before and after any
change. Temperature control is not involved.
"""

from __future__ import annotations

from npg_chamber.devices.pyrometer import ImpacIPE140, PyrometerSerialConfig


def main() -> None:
    device = ImpacIPE140(PyrometerSerialConfig(port="COM10", baudrate=38400, address="00"))
    try:
        device.open()
        before_parameters = device.read_parameter_string()
        before = device.read_emissivity_percent()
        print("IMPAC IPE 140 emissivity check")
        print("Port: COM10 | 38400 baud | 8E1 | address 00")
        print(f"Parameter reply before: {before_parameters}")
        print(f"Confirmed emissivity before: {before:.0f}%")
        print()
        raw = input("Enter a new whole emissivity percentage (10-100), or press Enter for read-only: ").strip()
        if not raw:
            print("No setting changed.")
            return
        requested = float(raw.replace(",", "."))
        # Validate before asking for final confirmation. This chamber unit's
        # `pa` reply and LCD expose whole percentages, so use values such as
        # 10, 11 or 35 rather than decimal percentages.
        device._format_emissivity(requested)
        answer = input(f"Change emissivity from {before:.0f}% to {requested:.0f}%? Type YES to continue: ").strip()
        if answer != "YES":
            print("Change cancelled.")
            return
        confirmed = device.set_emissivity_percent(requested, verify=True)
        after_parameters = device.read_parameter_string()
        print()
        print(f"Parameter reply after:  {after_parameters}")
        print(f"Confirmed emissivity after: {confirmed:.0f}%")
        if abs(confirmed - requested) <= 0.51:
            print("SUCCESS: the pyrometer readback confirms the new emissivity.")
            print("The LCD should show the new percentage when its parameter display is refreshed.")
        else:
            print("FAILED: the readback does not match the requested value.")
    finally:
        device.close()
        print("COM10 closed.")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}")
        print("Close InfraWin and every chamber phase before retrying; only one program can use COM10.")
    finally:
        input("Press Enter to close...")
