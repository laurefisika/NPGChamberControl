from __future__ import annotations

import socket

import pytest

from npg_chamber.devices.coscon_udp import (
    CosconReadOnlyClient,
    CosconReadOnlyViolation,
    first_integer,
    parse_coscon_fields,
)


class FakeSocket:
    def __init__(self, events, sent):
        self.events = events
        self.sent = sent
        self.timeout = None
        self.closed = False

    def settimeout(self, value):
        self.timeout = value

    def sendto(self, payload, target):
        self.sent.append((payload, target))

    def recvfrom(self, _size):
        event = self.events.pop(0)
        if isinstance(event, BaseException):
            raise event
        return event, ("192.168.236.186", 2005)

    def close(self):
        self.closed = True


class FakeSocketFactory:
    def __init__(self, events):
        self.events = list(events)
        self.sent = []
        self.created = []

    def __call__(self, family, kind):
        assert family == socket.AF_INET
        assert kind == socket.SOCK_DGRAM
        sock = FakeSocket(self.events, self.sent)
        self.created.append(sock)
        return sock


def test_get_status_uses_udp_port_2005_and_cr_terminator():
    factory = FakeSocketFactory(
        [b'GetStatus OK:\rMode=Standby Interlock=OK Details="Ready"\r']
    )
    client = CosconReadOnlyClient(socket_factory=factory, retries=0)

    reply = client.get_status()

    assert factory.sent == [(b"GetStatus\r", ("192.168.236.186", 2005))]
    assert reply.ok is True
    assert reply.fields == {"Mode": "Standby", "Interlock": "OK", "Details": "Ready"}
    assert factory.created[0].closed is True


def test_state_changing_commands_are_rejected_before_socket_creation():
    factory = FakeSocketFactory([])
    client = CosconReadOnlyClient(socket_factory=factory)

    with pytest.raises(CosconReadOnlyViolation):
        client.query("SwitchToStandby")

    with pytest.raises(CosconReadOnlyViolation):
        client.query("SwitchToDegas")

    with pytest.raises(CosconReadOnlyViolation):
        client.query("SetNetwork IP=192.168.236.20")

    assert factory.created == []
    assert factory.sent == []


def test_read_preset_is_the_only_read_command_accepting_a_parameter():
    factory = FakeSocketFactory(
        [b'ReadPreset OK:\rName="Default" Emission=20.0e-6 Energy=100\r']
    )
    client = CosconReadOnlyClient(socket_factory=factory, retries=0)

    reply = client.read_preset(1)

    assert reply.ok is True
    assert reply.fields["Name"] == "Default"
    assert factory.sent[0][0] == b"ReadPreset 1\r"

    with pytest.raises(CosconReadOnlyViolation):
        client.query("GetStatus extra")


def test_timeout_is_retried_once():
    factory = FakeSocketFactory([socket.timeout(), b"Info OK: COSCON_IS V1.012\r"])
    client = CosconReadOnlyClient(socket_factory=factory, retries=1, timeout_s=0.1)

    reply = client.info()

    assert reply.ok is True
    assert len(factory.sent) == 2
    assert all(payload == b"Info\r" for payload, _target in factory.sent)


def test_helpers_parse_documented_reply_shapes():
    response = 'GetStatus OK:\rMode=Operating Interlock=OK Details="Preset active"\r'
    assert parse_coscon_fields(response) == {
        "Mode": "Operating",
        "Interlock": "OK",
        "Details": "Preset active",
    }
    assert first_integer("ReadNumberOfPresets OK: 16") == 16
