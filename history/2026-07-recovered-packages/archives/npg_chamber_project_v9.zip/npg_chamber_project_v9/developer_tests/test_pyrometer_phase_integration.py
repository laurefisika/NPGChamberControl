from __future__ import annotations

from pathlib import Path


PHASES = [
    Path("npg_chamber/legacy_scripts/01_heat_up_calibration_legacy.py"),
    Path("npg_chamber/legacy_scripts/03_dp_dbba_evaporation_legacy.py"),
]


def test_phase1_and_phase3_have_monitoring_only_pyrometer_integration() -> None:
    for path in PHASES:
        text = path.read_text(encoding="utf-8")
        assert "ImpacIPE140" in text
        assert 'PyrometerSerialConfig(port="COM10", baudrate=38400, address="00")' in text
        assert "read_pyrometer" in text
        assert "the phase continues and monitoring will retry" in text
        assert "sample_temperature_data" in text
        assert "pyrometer_profile.json" in text
        assert "pyrometer_temperatures.csv" in text
        assert "Only one automatic write attempt is allowed per phase" in text


def test_phase1_and_phase3_reuse_temperature_graph_with_three_way_selector() -> None:
    for path in PHASES:
        text = path.read_text(encoding="utf-8")
        assert "OVEN PID" in text
        assert "PYROMETER" in text
        assert "SAMPLE EST." in text
        assert "setup_temperature_view_selector()" in text
        assert "Temperature comparison" in text
        assert "below calibrated range" in text
