from __future__ import annotations


import pytest

from npg_chamber.config.run_parameters import (
    AUTOMATION_PARAMETERS_ENV,
    all_default_values,
    encode_overrides,
    load_phase_overrides,
    non_default_overrides,
    specs_for_phase,
    validate_phase_values,
)


def test_all_packaged_parameter_defaults_validate() -> None:
    for phase, values in all_default_values().items():
        assert validate_phase_values(phase, values) == values
        assert non_default_overrides(phase, values) == {}


def test_run_only_override_round_trip() -> None:
    values = all_default_values()["heat"]
    values["HEATING_TRIGGER_TEMP_C"] = 250.0
    values["PID_KP_A_PER_C"] = 0.0025
    raw = encode_overrides("heat", values)
    loaded = load_phase_overrides("heat", {AUTOMATION_PARAMETERS_ENV: raw})
    assert loaded == {
        "HEATING_TRIGGER_TEMP_C": 250.0,
        "PID_KP_A_PER_C": 0.0025,
    }


def test_payload_is_phase_specific() -> None:
    raw = encode_overrides("heat", all_default_values()["heat"])
    with pytest.raises(RuntimeError, match="prepared for phase"):
        load_phase_overrides("dpdbba", {AUTOMATION_PARAMETERS_ENV: raw})


def test_hard_safety_limits_and_ports_are_not_editable() -> None:
    editable_keys = {
        spec.key
        for phase in all_default_values()
        for spec in specs_for_phase(phase)
    }
    assert "KEYSIGHT_HARD_STOP_A" not in editable_keys
    assert "KEYSIGHT_HARD_STOP_V" not in editable_keys
    assert "KEYSIGHT_OCP_A" not in editable_keys
    assert "PID_PORT" not in editable_keys
    assert "xgs600_port" not in editable_keys


def test_phase_relationship_validation() -> None:
    values = all_default_values()["sputter"]
    values["target_ar_pressure_mbar"] = 1e-4
    values["pressure_warning_mbar"] = 5e-5
    with pytest.raises(ValueError, match="target pressure"):
        validate_phase_values("sputter", values)


def test_phase4_minutes_are_converted_to_seconds_for_child_script() -> None:
    first_wait = next(spec for spec in specs_for_phase("anneal") if spec.key == "INITIAL_WAIT_S")
    assert first_wait.internal_value("7.5") == 450.0
    assert first_wait.format_display(450.0) == "7.5"

def test_phase2_coscon_targets_are_editable_with_operator_units() -> None:
    specs = {spec.key: spec for spec in specs_for_phase("sputter")}
    energy = specs["coscon_energy_v"]
    emission = specs["coscon_emission_a"]

    assert energy.format_display(2250.0) == "2250"
    assert energy.internal_value("2000") == 2000.0

    assert emission.format_display(0.010) == "10"
    assert emission.internal_value("8.5") == pytest.approx(0.0085)

    values = all_default_values()["sputter"]
    values["coscon_energy_v"] = 2000.0
    values["coscon_emission_a"] = 0.0085
    raw = encode_overrides("sputter", values)
    loaded = load_phase_overrides("sputter", {AUTOMATION_PARAMETERS_ENV: raw})
    assert loaded == {
        "coscon_energy_v": 2000.0,
        "coscon_emission_a": pytest.approx(0.0085),
    }


def test_phase2_coscon_target_editor_limits() -> None:
    values = all_default_values()["sputter"]
    values["coscon_energy_v"] = 3100.0
    with pytest.raises(ValueError, match="COSCON energy target"):
        validate_phase_values("sputter", values)

    values = all_default_values()["sputter"]
    values["coscon_emission_a"] = 0.001
    with pytest.raises(ValueError, match="COSCON emission target"):
        validate_phase_values("sputter", values)

