from pathlib import Path


def test_unified_readme_exists_and_is_useful():
    readme = Path("READ ME.md")
    assert readme.is_file()
    text = readme.read_text(encoding="utf-8")
    required_terms = [
        "Standard Operating Procedure",
        "npg-chamber",
        "Heat up + Calibration",
        "Sputtering-Annealing",
        "DP-DBBA Evaporation",
        "NPG Annealings",
        "--run heat",
        "--run sputter",
        "--run dpdbba",
        "--run anneal",
        "GUI buttons",
        "Fallback",
        "Troubleshooting",
    ]
    for term in required_terms:
        assert term in text


def test_no_duplicated_markdown_documentation_files():
    # User-facing instructions are intentionally consolidated into one SOP.
    removed_duplicate_paths = [
        Path("README.md"),
        Path("docs"),
        Path("installation_notes"),
        Path("TEST_REPORT.md"),
    ]
    for path in removed_duplicate_paths:
        assert not path.exists(), f"Duplicated documentation should not exist: {path}"


def test_useful_support_documents_are_kept():
    for path in ["CHANGELOG.md", "LICENSE.md", "SOURCE_CODE_MANIFEST.json"]:
        p = Path(path)
        assert p.is_file(), path
        assert p.read_text(encoding="utf-8").strip(), path


def test_original_script_backup_is_kept_and_documented():
    backup = Path("original_scripts_backup")
    assert backup.is_dir()
    assert len(list(backup.glob("*.py"))) == 4

    readme_text = Path("READ ME.md").read_text(encoding="utf-8")
    changelog_text = Path("CHANGELOG.md").read_text(encoding="utf-8")
    assert "original_scripts_backup/" in readme_text
    assert "recovery/reference" in readme_text
    assert "Original-script backup preservation" in changelog_text


def test_dead_helper_modules_remain_removed():
    removed_paths = [
        Path("npg_chamber/config/defaults.py"),
        Path("npg_chamber/common/prompts.py"),
        Path("npg_chamber/common/timing.py"),
    ]
    for path in removed_paths:
        assert not path.exists(), f"Unused helper should not exist: {path}"
