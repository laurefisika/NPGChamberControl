from __future__ import annotations

import hashlib
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_packaged_legacy_files_match_manifest() -> None:
    manifest = json.loads((PROJECT_ROOT / "SOURCE_CODE_MANIFEST.json").read_text(encoding="utf-8"))
    for entry in manifest:
        legacy_path = PROJECT_ROOT / entry["packaged_legacy"]
        resource_path = PROJECT_ROOT / entry["packaged_resource"]
        assert legacy_path.is_file()
        assert resource_path.is_file()
        assert sha256(legacy_path) == entry["sha256"]
        assert sha256(resource_path) == entry["sha256"]
        assert sha256(legacy_path) == sha256(resource_path)


def test_workflow_entry_points_delegate_to_packaged_scripts() -> None:
    workflow_files = [
        "heat_calibration.py",
        "sputter_anneal.py",
        "dp_dbba_evaporation.py",
        "npg_annealing.py",
    ]
    for name in workflow_files:
        text = (PROJECT_ROOT / "npg_chamber" / "workflows" / name).read_text(encoding="utf-8")
        assert "run_legacy_workflow" in text
        assert "exact packaged" in text
