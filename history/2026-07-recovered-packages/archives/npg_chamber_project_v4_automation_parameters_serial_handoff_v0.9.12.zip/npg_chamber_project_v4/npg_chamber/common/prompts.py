"""Reusable terminal prompt helpers."""

from __future__ import annotations


def ask_nonempty_text(prompt: str) -> str:
    """Ask repeatedly until the user enters non-empty text."""

    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("Please enter a non-empty value.")


def ask_positive_float(prompt: str) -> float:
    """Ask repeatedly until the user enters a positive number."""

    while True:
        raw = input(prompt).strip().replace(",", ".")
        try:
            value = float(raw)
            if value > 0:
                return value
        except ValueError:
            pass
        print("Please enter a positive number.")


def ask_choice(prompt: str, allowed: set[str]) -> str:
    """Ask until the user enters one of the allowed choices."""

    normalized_allowed = {item.lower() for item in allowed}
    while True:
        value = input(prompt).strip().lower()
        if value in normalized_allowed:
            return value
        print(f"Please choose one of: {', '.join(sorted(normalized_allowed))}")
