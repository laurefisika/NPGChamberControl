"""Path and filename helpers."""

from __future__ import annotations

import re
from importlib import resources
from pathlib import Path


INVALID_FILENAME_CHARS = r'[<>:"/\\|?*]+'
DATA_SAMPLES_FOLDER = "Data Samples"

PHASE_DATA_FOLDERS: dict[str, str] = {
    "heat": "Heat up + Calibration Data",
    "sputter": "Sputtering-Annealing Data",
    "dpdbba": "DP-DBBA Evaporation Data",
    "anneal": "NPG Annealing Data",
}


def project_root() -> Path:
    """Return the project root when running from the source tree."""

    return Path(__file__).resolve().parents[2]


def active_scripts_dir() -> Path:
    """Return the folder containing the scripts launched by ``npg-chamber``.

    In source/editable mode, the launcher uses ``original_scripts_backup/`` so
    the files are easy to inspect and run directly. In wheel installations,
    the scripts are packaged inside ``npg_chamber/legacy_scripts/``.
    """

    source_scripts = project_root() / "original_scripts_backup"
    if source_scripts.exists():
        return source_scripts

    packaged_scripts = resources.files("npg_chamber.legacy_scripts")
    return Path(str(packaged_scripts))


def legacy_dir() -> Path:
    """Backward-compatible alias for the active script folder."""

    return active_scripts_dir()


def data_samples_dir() -> Path:
    """Return the data folder used by all workflow runs.

    In source/editable mode, data are saved in the project root. In an installed
    wheel, the package lives in site-packages, so data are saved in the current
    working directory instead.
    """

    root = project_root()
    if not ((root / "pyproject.toml").exists() and (root / "npg_chamber").exists()):
        root = Path.cwd()

    path = root / DATA_SAMPLES_FOLDER
    path.mkdir(parents=True, exist_ok=True)
    return path


def phase_data_dir(workflow_key: str) -> Path:
    """Return the dedicated data parent folder for one workflow."""

    try:
        folder_name = PHASE_DATA_FOLDERS[workflow_key]
    except KeyError as exc:
        valid = ", ".join(sorted(PHASE_DATA_FOLDERS))
        raise ValueError(f"Unknown workflow {workflow_key!r}. Valid values: {valid}") from exc

    path = data_samples_dir() / folder_name
    path.mkdir(parents=True, exist_ok=True)
    return path


def ensure_all_data_sample_folders() -> None:
    """Create all standard data folders."""

    for key in PHASE_DATA_FOLDERS:
        phase_data_dir(key)


def safe_filename(text: str, fallback: str = "unnamed_run") -> str:
    """Convert user text into a filesystem-safe name."""

    safe = re.sub(INVALID_FILENAME_CHARS, "_", text).strip()
    safe = re.sub(r"\s+", " ", safe)
    return safe or fallback


def make_unique_dir(base_dir: Path, folder_name: str) -> Path:
    """Create a directory; if it exists, append a numeric suffix."""

    base_dir.mkdir(parents=True, exist_ok=True)
    root = base_dir / safe_filename(folder_name)
    if not root.exists():
        root.mkdir(parents=True)
        return root

    counter = 2
    while True:
        candidate = base_dir / f"{root.name} {counter}"
        if not candidate.exists():
            candidate.mkdir(parents=True)
            return candidate
        counter += 1
