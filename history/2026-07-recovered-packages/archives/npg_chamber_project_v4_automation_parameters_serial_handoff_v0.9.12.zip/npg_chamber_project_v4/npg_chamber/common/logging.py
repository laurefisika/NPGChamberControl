"""Small logging helpers for terminal scripts."""

from __future__ import annotations

from datetime import datetime

try:
    from colorama import Fore, Style, init as colorama_init
except ImportError:  # pragma: no cover - fallback for minimal environments
    class _Dummy:
        def __getattr__(self, _name: str) -> str:
            return ""

    Fore = Style = _Dummy()  # type: ignore

    def colorama_init(*_args, **_kwargs):
        return None


def init_colors() -> None:
    colorama_init()


def timestamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def banner(message: str) -> None:
    line = "=" * max(10, len(message))
    print(f"\n{Fore.CYAN}{line}\n{message}\n{line}{Style.RESET_ALL}\n")


def info(message: str) -> None:
    print(f"{Fore.GREEN}[{timestamp()}] {message}{Style.RESET_ALL}")


def warn(message: str) -> None:
    print(f"{Fore.YELLOW}[{timestamp()}] WARNING: {message}{Style.RESET_ALL}")


def error(message: str) -> None:
    print(f"{Fore.RED}[{timestamp()}] ERROR: {message}{Style.RESET_ALL}")
