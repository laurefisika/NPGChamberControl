"""Timing helpers."""

from __future__ import annotations

import threading
import time


def clamp(value: float, low: float, high: float) -> float:
    """Clamp value into [low, high]."""

    return max(low, min(value, high))


def sleep_interruptibly(
    total_s: float,
    stop_event: threading.Event,
    chunk_s: float = 0.2,
) -> bool:
    """Sleep while periodically checking a stop event.

    Returns True if the full sleep completed, False if interrupted.
    """

    deadline = time.time() + max(0.0, total_s)
    while time.time() < deadline:
        if stop_event.is_set():
            return False
        remaining = deadline - time.time()
        time.sleep(min(chunk_s, remaining))
    return not stop_event.is_set()
