"""Shared default constants.

This file is intentionally small for now. Experimental setpoints still live
inside the legacy scripts until each workflow is refactored safely.
"""

DEFAULT_READ_INTERVAL_S = 2.0
DEFAULT_DATA_SAVE_INTERVAL_S = 5.0
DEFAULT_GUI_REFRESH_INTERVAL_S = 0.15
