from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PHASE_01 = ROOT / "npg_chamber" / "legacy_scripts" / "01_heat_up_calibration_legacy.py"
PHASE_03 = ROOT / "npg_chamber" / "legacy_scripts" / "03_dp_dbba_evaporation_legacy.py"
STYLE_HELPER = ROOT / "npg_chamber" / "common" / "phase_dashboard_style.py"


COMMON_PANEL_LABELS = (
    "Live controls and run status",
    "Editable heating targets",
    "Ramp-up settings",
    "Manual current override",
    "Operator controls",
    "Process status",
    "Last action",
    "Apply targets",
    "Reset targets",
    "Steps mode",
    "Slope mode",
    "Set manual current",
    "Resume automatic",
    "Open shutter",
    "Close shutter",
    "Abort / safe stop",
)


def _source(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_phase_01_and_03_use_the_same_dashboard_language():
    phase_01 = _source(PHASE_01)
    phase_03 = _source(PHASE_03)
    for label in COMMON_PANEL_LABELS:
        assert label in phase_01
        assert label in phase_03


def test_phase_01_and_03_reserve_vertical_space_for_titles_and_selector():
    for source in (_source(PHASE_01), _source(PHASE_03)):
        assert "hspace=0.60" in source
        assert "top=0.865" in source
        assert "y = bbox.y1 + 0.040" in source
        assert "height = 0.021" in source
        assert "pad=8" in source


def test_phase_01_and_03_use_shared_presentation_only_style_helper():
    helper = _source(STYLE_HELPER)
    assert "presentation-only helpers" in helper
    assert "style_measurement_axis" in helper
    assert "add_panel_card" in helper
    assert "create_phase_badge" in helper
    for source in (_source(PHASE_01), _source(PHASE_03)):
        assert "from npg_chamber.common.phase_dashboard_style import" in source
        assert "update_phase_badge(phase_title_text" in source


def test_redundant_pyrometer_emissivity_launcher_is_removed():
    assert not (ROOT / "CHECK_PYROMETER_EMISSIVITY.bat").exists()
    assert not (ROOT / "diagnostic_tools" / "check_pyrometer_emissivity.py").exists()
    assert "CHECK_PYROMETER_EMISSIVITY.bat" not in _source(ROOT / "MANIFEST.in")
