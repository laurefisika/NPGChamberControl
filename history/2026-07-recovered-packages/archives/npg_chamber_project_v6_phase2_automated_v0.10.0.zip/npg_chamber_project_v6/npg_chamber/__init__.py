"""NPG chamber controller package."""

__version__ = "0.10.0"
