from __future__ import annotations

import pytest

from npg_chamber.devices.coscon_udp import (
    COSCONCommandError,
    COSCONUDPClient,
    parse_diagnostic_values,
    parse_monitor_values,
    parse_status,
    parse_target_values,
)


def test_parse_status_accepts_actual_error_mode_as_valid_status() -> None:
    status = parse_status(
        'GetStatus OK: Mode=Error Interlock=Ok '
        'Details="Error: HV-Module Energy Overload"'
    )
    assert status.mode == "Error"
    assert status.interlock_ok
    assert "HV-Module Energy Overload" in status.details


def test_parse_actual_degas_mode_alias() -> None:
    status = parse_status(
        'GetStatus OK: Mode=Degassing Interlock=Ok '
        'Details="Degassing: Warming up Filament"'
    )
    assert status.mode_key == "degassing"


def test_parse_monitor_target_and_diagnostic_values() -> None:
    monitor = parse_monitor_values(
        "GetMonitorValues OK: VEnergy=2.250010e+03 "
        "IFilament=4.543960e+00 IEmission=1.003700e-02"
    )
    assert monitor.energy_v == pytest.approx(2250.01)
    assert monitor.emission_current_a == pytest.approx(0.010037)

    target = parse_target_values(
        "GetTargetValues OK: Emission=1.000000e-02 Energy=2.250000e+03"
    )
    assert target.energy_v == pytest.approx(2250.0)

    diagnostic = parse_diagnostic_values(
        "GetDiagnosticValues OK: IEnergy=2.180450e-05 "
        "VFilament=4.099160e+00 VAnode=1.195160e+02 "
        "VRepeller=-7.965030e+01 TemperatureHV=31.5 TemperatureEM=45.1"
    )
    assert diagnostic.temperature_hv_c == pytest.approx(31.5)


def test_strict_command_whitelist() -> None:
    assert COSCONUDPClient.command_is_allowed("GetStatus")
    assert COSCONUDPClient.command_is_allowed("SwitchToDegas")
    assert COSCONUDPClient.command_is_allowed(
        "SwitchToOperate Emission=1.000000e-02 Energy=2250"
    )
    assert not COSCONUDPClient.command_is_allowed("Reset")
    assert not COSCONUDPClient.command_is_allowed("SetNetwork IP=1.2.3.4")


def test_blocked_command_fails_before_network_use() -> None:
    client = COSCONUDPClient()
    with pytest.raises(COSCONCommandError):
        client.send("Reset")
