from __future__ import annotations

import importlib.util
import threading
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace

from npg_chamber.devices.coscon_udp import COSCONMonitorValues, COSCONStatus


PHASE2_PATH = Path("npg_chamber/legacy_scripts/02_sputtering_annealing_legacy.py")


def load_phase2_module():
    if "serial" not in sys.modules:
        serial_stub = ModuleType("serial")
        serial_stub.Serial = object
        sys.modules["serial"] = serial_stub
    spec = importlib.util.spec_from_file_location("phase2_runtime_for_test", PHASE2_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class FakeUI:
    def is_running(self) -> bool:
        return False


class FakeLogger:
    def __init__(self) -> None:
        self.notes: list[str] = []

    def log_snapshot(self, _snap: dict, note: str = "") -> None:
        self.notes.append(note)


class FakeGauge:
    def __init__(self, values: list[float]) -> None:
        self.values = list(values)

    def read_pressure_mbar(self, *, strict: bool = False) -> float:
        assert strict
        if len(self.values) > 1:
            return self.values.pop(0)
        return self.values[0]


class FakeCoscon:
    def __init__(self, statuses: list[COSCONStatus], monitors: list[COSCONMonitorValues]) -> None:
        self.statuses = list(statuses)
        self.monitors = list(monitors)
        self.calls: list[str] = []

    def get_status(self) -> COSCONStatus:
        self.calls.append("GetStatus")
        if len(self.statuses) > 1:
            return self.statuses.pop(0)
        return self.statuses[0]

    def get_monitor_values(self) -> COSCONMonitorValues:
        self.calls.append("GetMonitorValues")
        if len(self.monitors) > 1:
            return self.monitors.pop(0)
        return self.monitors[0]

    def get_target_values(self):
        self.calls.append("GetTargetValues")
        return SimpleNamespace(emission_current_a=0.01, energy_v=2250.0)

    def get_diagnostic_values(self):
        self.calls.append("GetDiagnosticValues")
        return SimpleNamespace()

    def validate_operate_target(self, emission_a: float, energy_v: float) -> str:
        self.calls.append(f"Validate:{emission_a}:{energy_v}")
        return "ValidateOperateTarget OK"

    def switch_to_operate(self, emission_a: float, energy_v: float) -> str:
        self.calls.append(f"Operate:{emission_a}:{energy_v}")
        return "SwitchToOperate OK"

    def switch_to_standby(self) -> str:
        self.calls.append("Standby")
        return "SwitchToStandby OK"

    def switch_to_off(self) -> str:
        self.calls.append("Off")
        return "SwitchToOff OK"


def status(mode: str, details: str = "") -> COSCONStatus:
    return COSCONStatus(mode=mode, interlock="Ok", details=details, raw=f"Mode={mode}")


def monitor(energy: float, emission: float, filament: float = 4.5) -> COSCONMonitorValues:
    return COSCONMonitorValues(
        energy_v=energy,
        filament_current_a=filament,
        emission_current_a=emission,
        raw="monitor",
    )


def make_controller(module, coscon: FakeCoscon, gauge: FakeGauge):
    controller = object.__new__(module.SputterAnnealController)
    controller.cfg = SimpleNamespace(
        coscon_emission_target_a=0.010,
        coscon_energy_target_v=2250.0,
        coscon_energy_tolerance_v=50.0,
        coscon_emission_tolerance_a=0.001,
        coscon_stable_samples=5,
        coscon_operate_timeout_s=5.0,
        coscon_standby_timeout_s=5.0,
        coscon_off_timeout_s=5.0,
        coscon_poll_s=0.0,
        pressure_min_mbar=1.0e-5,
        pressure_warning_mbar=5.0e-5,
        degas_abort_pressure_mbar=1.0e-4,
    )
    controller.state = module.MonitorState()
    controller.state_lock = threading.RLock()
    controller.background_fault_lock = threading.RLock()
    controller.background_fault = None
    controller.coscon_activation_requested = False
    controller.coscon_safe_state_confirmed = False
    controller.coscon = coscon
    controller.xgs600 = gauge
    controller.logger = FakeLogger()
    controller.ui = FakeUI()
    return controller


def test_automatic_operate_waits_for_measured_output() -> None:
    module = load_phase2_module()
    statuses = [
        status("Standby"),
        status("SwitchingToOperate"),
        status("Operating"),
        *[status("Operating") for _ in range(5)],
    ]
    monitors = [
        monitor(0.0, 0.0, 3.0),
        monitor(0.0, 0.005),
        monitor(9.8, 0.010),
        *[monitor(2250.0, 0.010) for _ in range(5)],
    ]
    coscon = FakeCoscon(statuses, monitors)
    controller = make_controller(module, coscon, FakeGauge([2.0e-5]))

    controller.automatic_start_sputtering(1)

    assert controller.coscon_activation_requested
    assert not controller.coscon_safe_state_confirmed
    assert coscon.calls.count("Operate:0.01:2250.0") == 1
    assert any(note.startswith("COSCON snapshot") for note in controller.logger.notes)


def test_degas_safe_stop_uses_off_not_standby() -> None:
    module = load_phase2_module()
    coscon = FakeCoscon(
        [status("Degassing"), status("Off")],
        [monitor(0.0, 0.0)],
    )
    controller = make_controller(module, coscon, FakeGauge([1.0e-8]))

    controller._best_effort_coscon_safe_stop("test")

    assert "Off" in coscon.calls
    assert "Standby" not in coscon.calls
    assert controller.coscon_safe_state_confirmed
