from __future__ import annotations

from pathlib import Path


PHASE2 = Path("npg_chamber/legacy_scripts/02_sputtering_annealing_legacy.py")


def test_phase2_uses_direct_coscon_udp_and_no_embedded_web_control() -> None:
    text = PHASE2.read_text(encoding="utf-8")
    assert "COSCONUDPClient" in text
    assert "automatic_degassing_step" in text
    assert "automatic_start_sputtering" in text
    assert "automatic_switch_to_standby" in text
    assert ".validate_operate_target(" in text
    assert "<iframe" not in text
    assert "__COSCON_URL__" not in text


def test_phase2_keeps_manual_leak_valve_and_verified_pressure_gate() -> None:
    text = PHASE2.read_text(encoding="utf-8")
    assert "Argon valve opened" in text
    assert "Argon valve closed" in text
    assert "wait_for_stable_argon_pressure" in text
    assert "read_pressure_mbar(strict=True)" in text
    assert "degas_abort_pressure_mbar" in text


def test_phase2_does_not_expose_unsafe_coscon_commands() -> None:
    device_text = Path("npg_chamber/devices/coscon_udp.py").read_text(encoding="utf-8")
    assert '"SwitchToDegas"' in device_text
    assert '"SwitchToStandby"' in device_text
    assert '"SwitchToOff"' in device_text
    assert 'return self.send("Reset")' not in device_text
    assert "SetNetwork" not in device_text
    assert "StorePreset" not in device_text
    assert "DeletePreset" not in device_text
